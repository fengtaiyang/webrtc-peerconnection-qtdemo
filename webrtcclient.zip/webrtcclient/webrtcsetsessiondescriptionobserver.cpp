#include "webrtcsetsessiondescriptionobserver.h"

WebrtcSetSessionDescriptionObserver::WebrtcSetSessionDescriptionObserver(QObject *parent)
    : QObject{parent}
{

}
