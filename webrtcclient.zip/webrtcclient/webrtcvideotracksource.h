#ifndef WEBRTCVIDEOTRACKSOURCE_H
#define WEBRTCVIDEOTRACKSOURCE_H

#include "pc/video_track_source.h"
#include "test/vcm_capturer.h"
#include <QObject>

class WebrtcVideoTrackSource : public QObject,
                               public webrtc::VideoTrackSource
{
    Q_OBJECT
public:
    explicit WebrtcVideoTrackSource(QObject *parent = nullptr) = delete;

    static rtc::scoped_refptr<WebrtcVideoTrackSource> create();

//signals:
protected:
    explicit WebrtcVideoTrackSource(
            std::unique_ptr<webrtc::test::VcmCapturer> capturer)
        : VideoTrackSource(/*remote=*/false), capturer_(std::move(capturer)) {}
private:
    rtc::VideoSourceInterface<webrtc::VideoFrame>* source() override {
        return capturer_.get();
    }
    std::unique_ptr<webrtc::test::VcmCapturer> capturer_;
};

#endif // WEBRTCVIDEOTRACKSOURCE_H
